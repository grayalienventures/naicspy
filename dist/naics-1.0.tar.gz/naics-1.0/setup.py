from html.entities import name2codepoint
from setuptools import setup, find_packages


setup (
    name='naics',
    version='1.0',
    license='MIT',
    author='Gray Alien Ventures',
    author_email='info@intp.io',
    packages=find_packages(),
)